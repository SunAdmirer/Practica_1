﻿#pragma warning(disable:4996)
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <Windows.h>

struct CountryStruct
{
    char Country[100];
    char Capital[100];
    char Lenguage[100];
    int Population;
    int Space;
    char Сurrency[100];
    char President[100];
};

int count;
CountryStruct* arr = (CountryStruct*)
malloc(sizeof(CountryStruct) * count);

int DisplayMenu()
{
    int num;
    printf("| 1 - load/open file                               |\n");
    printf("| 2 - add new data                                 |\n");
    printf("| 3 - show all data about countries                |\n");
    printf("| 4 - saving                                       |\n");
    printf("| 5 - seacrhing                                    |\n");
    printf("| 6 - delete info                                  |\n");
    printf("| 0 - exit                                         |\n");
    scanf(" %d", &num);
    return num;
}

CountryStruct countries()
{
    CountryStruct countries;
    printf("  Country: ");
    scanf("%s", countries.Country);
    printf("  Capital: ");
    scanf("%s", countries.Capital);
    printf("  Population: ");
    scanf_s("%d", &countries.Population);
    printf("  Space: ");
    scanf_s("%d", &countries.Space);
    printf("  Currency: ");
    scanf("%s", countries.Сurrency);
    printf("  Lenguage: ");
    scanf("%s", countries.Lenguage);
    printf("  President: ");
    scanf("%s", countries.President);
    return countries;
}

void Print(CountryStruct countries)
{
    printf("\n");
    printf("General information about Countries: %s %s %d %d %s %s %s \n",
        countries.Country, countries.Capital, countries.Population, countries.Space, countries.Lenguage, countries.Сurrency, countries.President);
    printf("\n");
}



int load()
{
    system("cls");
    FILE* lb = fopen("text.txt", "r");
    if ((lb = fopen("text.txt", "r")) == NULL)
    {
        printf("Error\n");
        return 0;
    }
    else printf("Opened\n");
    fread(&count, sizeof(int), 1, lb);
    CountryStruct* arr1 = (CountryStruct*)
        malloc(count * sizeof(CountryStruct));
    fread(arr1, sizeof(CountryStruct), count, lb);
    free(arr);
    arr = arr1;

    fclose(lb);
}

void Print(CountryStruct* arr, int count)
{
    for (int i = 0; i < count; i++)
    {
        printf("|%-2d|", i + 1);
        Print(arr[i]);
    }
}

void add()
{
    int b;
    printf("\n number:");
    scanf_s("%d", &b);
    CountryStruct* arr1 = (CountryStruct*)calloc((count + b), sizeof(CountryStruct));
    for (int i = 0; i < count; i++)
        arr[i] = arr1[i];
    free(arr);
    arr = arr1;
    for (int i = count; i < count + b; i++)
    {
        printf("--- Country[%d] ---\n", i + 1);
        arr[i] = countries();
    }
    count += b;
}

void txtsaving()
{
    system("cls");
    FILE* lb = fopen("text.txt", "a");//a
    fwrite(&count, sizeof(int), 1, lb
    );
    fwrite(arr, sizeof(CountryStruct), count, lb);
    fclose(lb);
    printf("File saved!\n");
}


void SearchCountry(CountryStruct* arr, int count)
{
    char countrySearch[30];
    int rsCount = 0;
    printf(" Country: ");
    scanf("%s", &countrySearch);
    printf("\n");
    for (int i = 0; i < count; i++)
    {
        if (strcmp(arr[i].Country, countrySearch) == 0)
        {
            Print(arr[i]);
            rsCount++;
        }
        else
            printf("Undefined!!!");
    }
    if (rsCount == 0);
    printf(" \n");
}

void SearchCapital(CountryStruct * arr, int count)
{
    char capitalSearch[50];
    int rsCount1 = 0;
    printf(" Capital: ");
    scanf("%s", &capitalSearch);
    for (int i = 0; i < count; i++)
    {
        if (strcmp(arr[i].Capital, capitalSearch) == 0)
        {
            Print(arr[i]);
            rsCount1++;
        }
        else
            printf("Undefined!!!");
    }
    if (rsCount1 == 0);
    printf(" \n");
}

void SearchPresident(CountryStruct* arr, int count)
{
    char presidentSearch[50];
    int rsCount2 = 0;
    printf(" Capital: ");
    scanf("%s", &presidentSearch);
    for (int i = 0; i < count; i++)
    {
        if (strcmp(arr[i].President, presidentSearch) == 0)
        {
            Print(arr[i]);
            rsCount2++;
        }
        else
            printf("Undefined!!!");
    }
    if (rsCount2 == 0);
    printf(" \n");
}

void deleting()
{
    int li;
    printf("\n Choose element: \n");
    scanf("%d", &li);
    for (int i = li - 1; i < count - 1; i++)
        arr[i] = arr[i + 1];
    CountryStruct* arr1 = (CountryStruct*)malloc((count - 1) * sizeof(CountryStruct));
    count--;
    for (int i = 0; i < count; i++)
        arr1[i] = arr[i];
    free(arr);
    arr = arr1;
    printf("Information deleted! \n");

}

int main()
{
    int choise;
    do
    {
        choise = DisplayMenu();
        switch (choise) {
        case 1:
            load();
            break;

        case 2:
            add();
            break;

        case 3: printf("--------COLLECTION--------\n");
            Print(arr, count);
            break;

        case 4:
            txtsaving();
            break;
        case 5:
            int search;
            do {
                printf("|1.search by Country                   |\n");
                printf("|2.search by Capital                   |\n");
                printf("|3.search by President                 |\n");
                printf("|0.---main menu---                     |\n");
                printf(" -->  ");
                scanf_s("%d", &search);
                switch (search)
                {
                case 1:SearchCountry(arr, count);
                    break;
                case 2:SearchCapital(arr, count);
                    break;
                case 3:SearchPresident(arr, count);
                    break;

                }

            } while (search != 0);
            break;
        case 6:
            deleting();
            break;
        }
    } while (choise != 0);
    return 0;
}